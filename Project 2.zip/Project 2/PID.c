#include "simpletools.h"
#include "PID.h" 

// Define global variables
double setPoint = 0.0;
double PIDinput;
double PIDoutput;

double Kp = 0.7;
double Ki = 0.04375;
double Kd = 0.175;

// Time Variables
unsigned long lastTime;

double errSum = 0, lastErr = 0;

// Sample time in milliseconds
double sampleTime = 100;


double ComputePID(double PIDinput) {
    unsigned long now = millis();
    double timeChange = (double)(now - lastTime) / 1000.0;           // Convert to seconds

    if(timeChange >= (sampleTime / 1000.0)) {                       // Ensure timeChange is in seconds
        double Error = PIDinput - setPoint;
        
        errSum += (Error * timeChange);                             // Integral is error accumulated over time
        double dErr = (Error - lastErr) / timeChange;               // Derivative is rate of error change
        
        PIDoutput = (Kp * Error) + (Ki * errSum) + (Kd * dErr);

                                                                  
        if(PIDoutput > 100) {                                       // Saturate PIDoutput to max/min values
          PIDoutput = 100.00;
        } 
        if(PIDoutput < -100) {
          PIDoutput = -100.00;
        }
        
        lastErr = Error;
        lastTime = now;
       
            
        return PIDoutput;
}
}

