// motor_control.h
#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H


/*
This function receives two values and moves the wheels of the robot either clockwise or anticlockwise depending on the
sign of the value received
*/
void motor_drive(int leftSpeed, int rightSpeed);



/*
Stops all wheels from moving
*/
void motor_stop();

#endif

