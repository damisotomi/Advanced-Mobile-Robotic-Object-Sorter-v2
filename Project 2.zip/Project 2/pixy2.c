#include <stdint.h>
#include "pixy2.h"
#include "serial.h"

serial *pixy2;

uint8_t response[BUF_SIZE];


int32_t pixy2_start(uint8_t rxpin, uint8_t txpin, uint16_t baud)
{
  pixy2 = serial_open(rxpin, txpin, 0, baud);
  
  return (pixy2 != NULL) ? RESULT_OK : RESULT_ERROR;
}




uint8_t pixy2_getBlocks(uint8_t sigMap, uint8_t maxBlocks)
{
  clearBuffer();

  serial_txChar(pixy2, 0xAE);
  serial_txChar(pixy2, 0xC1);
  serial_txChar(pixy2, REQUEST_BLOCKS);
  serial_txChar(pixy2, 0x02);
  serial_txChar(pixy2, sigMap);
  serial_txChar(pixy2, maxBlocks);

  recvPacket();

  if (validateChecksum() != RESULT_OK) {
    return RESULT_CHECKSUM_ERROR;
  }
  else {
    if (response[2] == RESPONSE_BLOCKS) {
      return response[3] / 14;
    }
    else
      return (int32_t)(0xFFFFFF00 | response[2]);
  }
}


int32_t pixy2_extractBlock(uint8_t i, uint16_t *block)
{
  uint8_t ofs = 6 + (i * BLOCK_SIZE);
  uint8_t j;

  if (response[2] == RESPONSE_BLOCKS) {
    if (i < (response[3] / 14)) {
      memcpy(block, &response[ofs], 14);
      return RESULT_OK;
    } 
  }     
  return RESULT_ERROR;
}


void clearBuffer()
{
  uint8_t i;

  for (i = 0; i < BUF_SIZE; i++)
    response[i] = 0;
}


uint8_t recvPacket()
{
  uint8_t len, b, payload;

  // get header
  for (len = 0; len < 6; len++) {
    b = serial_rxChar(pixy2);
    response[len] = (uint8_t)b;
  }

  // get size of payload
  payload = response[3];

  // get payload bytes if available
  while (payload-- > 0) {
    b = (uint8_t)serial_rxChar(pixy2);
    response[len++] = b;
  }

  return len;
}


int32_t validateChecksum()                                    // compare packet checksum to calcutated checksum
{
  uint16_t cs0 = extract16(4);
  uint16_t cs1 = 0;
  uint8_t  i   = response[3];                                 // length of payload
  uint8_t  j   = 6;                                           // starting index of payload bytes

  while (i-- > 0) {
    cs1 += response[j++];
  }

  return (cs1 == cs0) ? RESULT_OK : RESULT_ERROR;
}


uint16_t extract16(uint8_t i)
{
  return extractLE(i, 2);                                     // two bytes to 16-bit value
}


uint32_t extract32(uint8_t i)
{
  return extractLE(i, 4);                                     // four bytes to 32-bit value
}


uint32_t extractLE(uint8_t i, uint8_t n)                      // extract Little Endian value from response
{
  uint32_t result = 0;
  uint8_t j = 0;

  while (n-- > 0) {
    result |= response[i++] << j;
    j += 8;
  }
  return result;
}

