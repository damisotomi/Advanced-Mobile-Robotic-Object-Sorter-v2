#include "millis.h"

// Declare startTime as a static variable without initializing it here
static unsigned int startTime;

// Add a function to initialize startTime
void initMillis() {
    startTime = CNT;
}

unsigned long millis() {
    // Return the elapsed time in milliseconds since the program started
    return (CNT - startTime) / (CLKFREQ / 1000);
}

