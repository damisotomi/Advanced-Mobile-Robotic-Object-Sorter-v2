
// qtr_sensors.h
#ifndef QTR_SENSORS_H
#define QTR_SENSORS_H

#include <stdbool.h>

/*
An array to hold the 8 pins connected to the propeller microcontroller
*/
extern int sensorPins[8];

/*
A variable to store the value of the emiiter pin of the qtr sensor. The emitter pin controls the 8 LEDs of the QTR sensor
*/
extern int emitterPin;

/*
An array to hold the time it takes for each sensor to discharge
*/
extern int sensorValues[8];

/*
A variable to store the value of the number of sensors used on the qtr sensor
*/
extern const int sensorCount;

/*
An array to hold the minimum time it takes for each sensor to discharge during calibration
*/
extern int minValue[8];

/*
An array to hold the maxuimum time it takes for each sensor to discharge during calibration
*/
extern int maxValue[8];

/*
A global variable to keep track of the last position of the sensor
*/
extern int lastPosition;


/*
A variable to store the maximum time allowed for each sensor to discharge. Any time more than this gets capped to this value
*/
extern int _maxValue; 

/*
This function controls the emitter pin on the qtr sensor that controls the on state of the 8 LEDs
*/
void emittersOn(void);


/*
This function controls the emitter pin on the qtr sensor that controls the off state of the 8 LEDs
*/
void emittersOff(void);


/*
This function calibrates the 8 sensors 800 times and stores the maximum and minimum time it takes for each 
sensor to discharge in the maxValue and minValue arrays
*/
void calibrateSensors(void);


/*
This function reads the value of each sensor, stores the time it takes for the sensor to discharges in a sensorValues array.
It works the way the calibrateSensor function works but runs once.
*/
void readSensors(void);


/*
This function calls the readSensors() function and maps each value of the sensor to a range btw 0-1000.
*/
void readSensorsAndMap(void);


/*
This function calls the readSensorsAndMap() function and uses a weighted average calculation to calculate the line position
*/
int readLine(void);

#endif
