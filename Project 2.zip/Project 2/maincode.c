#include "simpletools.h"
#include "millis.h"
#include "qtr_sensors.h"
#include "PID.h"
#include "pixy2.h"
#include "servo.h"

#define RX2 1                                  //rx pin for the pixy 2 camera
#define TX2 0                                  //Tx pin for the pixy 2 camera
#define SIG_MAP CCC_SIG1 | CCC_SIG2 | CCC_SIG3
#define CC_MAP CCC_COLOR_CODES | SIG_MAP
#define LF_SPEED 100.0  
#define MIN_DISTANCE_1 12                     //Min Distance from camera to object 1 before motors stops
#define MIN_DISTANCE_2 12                     //Min Distance from camera to object 2 before motors stops

#define GRIPPER_SERVO_PIN 17                  //defines servo pin
#define GRIPPER_OPEN 1800                     //defines servo open position
#define GRIPPER_CLOSE 0                       //defines servo open position

volatile int gripperState = GRIPPER_OPEN;     //global variable to store gripper state
volatile int carActive = 1;                   //global variable to store car active state
volatile int cameraActive = 1;                //global variable to store camera active
volatile int checkAlignment = 0;               //global variable to store checkalignment state
volatile int finalSignature = 0;               //global variable to store the signature of the object picked


int alignmentCounter = 0;                     //global variable to store the alignment count
int driveCarCog;                               //global variable to store the cog value running drivecar function

uint16_t frameWidth = 316;                      // width of Pixy frame
uint16_t frameHeight;                           // height of Pixy frame
block_t b;                                      // target (block) values

void showError(int32_t code);                                   
void driveCar();                                //function that moves the car
void camera();                                  //function that runs the camera
void showSignatures();                          //function that constantly checks the signature of the object in view
void stopEverything();                          //stops motor and pwm activity
void controlGripper();                          //function to handle gripper
void pickItem();                                //function to control gripper state
void turnLeft90Degrees();                       //function to turn the car left 
void turnRight90Degrees();                      //function to turn the car right

int main() {  
       
    uint32_t ec = pixy2_start(RX2, TX2, 19200);
    if (ec != RESULT_OK) {
        showError(ec);
        while (1) {}
    } else {
        print("Pixy2 Serial Test\n\n");
    }
    
    pause(1000);
    calibrateSensors();                           // Perform calibration on sensors
    
    initMillis();                                  //initiate millis      
    driveCarCog=cog_run(driveCar, 256);            // starts pid and drives car on a separate cog
    cog_run(controlGripper, 128);                  // starts gripper control on a separate cog
    camera();                                      // starts the camera function on main cog
    
    pause(1000);                                      
    motor_drive(200,200); //150 before
    pause(200);
    motor_stop();

    pickItem();
    pause(1000);
    carActive = 1;                                //resumes car movement after picking item
    pause(1000);
    driveCarCog=cog_run(driveCar, 256);           // starts pid and drives car again on a separate cog
    
    pause(1000);                               

  
    int consecutiveCounts = 0;                    // Initialize the counter to track consecutive readings above threshold
     while(1) {
        int allAboveThreshold = 1;                // Flag to check if all sensors are above threshold
        for(int i = 0; i < sensorCount; i++) {   
            if(sensorValues[i] <= 850) {
                allAboveThreshold = 0;              // If any sensor is not above threshold, set flag to 0
                break;                              // Exit the loop early if a sensor doesn't meet the condition
            }
        }
        if(allAboveThreshold) {
            consecutiveCounts++;                    // Increments the counter if all sensors are above the threshold
            if(consecutiveCounts >= 2) {
                break;                             // Exit the while loop if the condition has been true for 2 iterations
            }
        } else {
            consecutiveCounts = 0;                  // Reset the counter if the condition is not met
        }
        pause(50);                                  // Small pause to prevent hogging the CPU
      } 

       carActive = 0;                               //stops car movement
       motor_stop();
       cog_end(driveCarCog);                        //stops the car cog
      
       pause(2000);                                 //makes a decision based on object signature
       if(finalSignature==1){
        turnRight90Degrees();
        }
       else if(finalSignature==2){
        turnLeft90Degrees();
        }
       pause(1000);
       gripperState = GRIPPER_OPEN;               //opens gripper to release objects
    
    return 0;
}



/*
 function to drive car using PID control. Depends on the state of carActive variable
 */
void driveCar() {
    while (carActive) {
        pause(80);
        double linePosition = readLine();           // Calculate the line position
        double linePosition_New = ((linePosition) * (200.0) / 7000.0) - 100.0;
        double output = ComputePID(linePosition_New);

        int lsp = LF_SPEED - output;
        int rsp = LF_SPEED + output;
        motor_drive((int)lsp, (int)rsp);   
    }
}

/*
 function to control the camera. Depends on the state of cameraActive variable
 */
void camera() {
    while (cameraActive) {
        showSignatures();
    }
}

void showSignatures() {
  int32_t nsigs;
  float distance1, distance2, distance3;
  const int leftThreshold = -22;                        //value gotten based on test
  const int rightThreshold = 14;  
  int aligned = 0;
  nsigs = pixy2_getBlocks(SIG_MAP, MAX_BLOCKS);

    if (nsigs < RESULT_OK) {
        showError(nsigs);
    } else {
        if (nsigs > 0) {
            for (uint8_t i = 0; i < nsigs; i++) {
                pixy2_extractBlock(i, &b.signature);  

                int area = b.width * b.height;
                
                distance1 = -0.0012 * area + 23.736;
                distance2 = -0.0012 * area + 23.736;
                distance3 = -0.001 * area + 21.233;
               
                int deviation = b.xpos-(frameWidth/2);
               
               if ((b.signature == 1 && distance1 < MIN_DISTANCE_1) ||(b.signature == 2 && distance2 < MIN_DISTANCE_2)) {

                   finalSignature= b.signature;
                   stopMovement();
     
                 }
                if (checkAlignment) {
                    if (deviation < leftThreshold) {
                         motor_drive(-80,80);
                    } else if (deviation > rightThreshold) {
                         motor_drive(80,-80);
                    } else {                                //if aligned, loop runs for a while to ensure accurate alignment
                       if(alignmentCounter>=200){
                         cameraActive = 0;                 // stop the camera if aligned
                         checkAlignment = 0;               // Reset alignment checking
                         pause(1000);
                         return;
                        }
                        alignmentCounter+=1;
                }
                
            }
        }
    }
}
 
}

void stopMovement() {
    carActive = 0;                                         // Stops the driveCar function from running
    motor_stop();                                           // Stops motors immediately
    cog_end(driveCarCog);                                   // Stops the driveCar cog
    high(27);
    checkAlignment = 1;
}

void showError(int32_t code) {
    print("Pixy error: %d\n", code);
}

/*
 function to control the gripper 
 */
void controlGripper() {
    while(1) {
        if(gripperState == GRIPPER_CLOSE) {
            servo_angle(GRIPPER_SERVO_PIN, GRIPPER_CLOSE);
        } else if(gripperState == GRIPPER_OPEN) {
            servo_angle(GRIPPER_SERVO_PIN, GRIPPER_OPEN);
        }
    }
}

/*
 function to control the gripperstate 
 */
void pickItem(){
  gripperState = GRIPPER_CLOSE;
  }    

  
void turnRight90Degrees(){
  motor_drive(200, 0);
  pause(350); 
  motor_stop();
  }
 
void turnLeft90Degrees(){
  motor_drive(0, 200); 
  pause(350); 
  motor_stop();
  }


