#ifndef PID_H
#define PID_H

// Declare global variables
extern double setPoint;                     // The desired value
extern double PIDinput;                     // The variable being controlled
extern double PIDoutput;                    // The control output

extern double Kp;                           // Proportional gain
extern double Ki;                           // Integral gain
extern double Kd;                           // Derivative gain
extern double errSum;
extern double lastErr;


                                            // Declare the PID computation function
double ComputePID(double PIDinput);
#endif


