
#ifndef MILLIS_H
#define MILLIS_H

#include "simpletools.h" 

// Function declarations
void initMillis();
unsigned long millis();

#endif /* MILLIS_H */
