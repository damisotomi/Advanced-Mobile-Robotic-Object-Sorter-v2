
// motor_control.c
#include "simpletools.h" 
#include "motor_control.h" r

void motor_drive(int leftSpeed, int rightSpeed) {                        
    pwm_start(1000);                             // PWM is started with a 1 kHz frequency
    set_outputs(5, 2, 0b0000);
    set_directions(5, 2,0b1111);
    if(leftSpeed>=0){
      pwm_set(3, 0, leftSpeed); 
      }
     else {
      pwm_set(2, 0,  -leftSpeed); 
       }
    
    if(rightSpeed >=0){
      pwm_set(4, 1, rightSpeed);
      }
     else{
       pwm_set(5, 1, -rightSpeed);
     }          
        
}

void motor_stop() {
                                                 // Stop motors by setting PWM duty cycle to 0
    pwm_set(2, 0, 0);
    pwm_set(3, 0, 0);
    pwm_set(4, 1, 0);
    pwm_set(5, 1, 0);           
    pwm_stop();                                  // Stop the PWM process
}


