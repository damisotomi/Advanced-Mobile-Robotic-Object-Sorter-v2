
// qtr_sensors.c
#include "simpletools.h" 
#include "qtr_sensors.h"


int lastPosition = -1;                             // a global variable to keep track of the last position
int sensorPins[8] = {7,8,9,10,11,12,13,14};        // Array of sensor pins
int emitterPin = 15;                               // Pin connected to your emitter (LED)
int sensorValues[8];                               // Array to store sensor values
const int sensorCount = 8;                         // Total number of sensors used
int _maxValue = 2500;                              // Maximum time to wait for sensor discharge
int minValue[8];                                   // Array to store minimum sensor values observed during calibration
int maxValue[8];                                   // Array to store maximum sensor values observed during calibration


void emittersOn() {
  high(emitterPin);                                 // Turn the emitter (LED) on
}

void emittersOff() {
  low(emitterPin);                                  // Turn the emitter (LED) off
}


void calibrateSensors() {
  high(26);                                          //led pin to indicate calibration has begun
  int maxSensorValues[8] = {0, 0, 0, 0, 0, 0, 0, 0}; // Temporary storage for max values per iteration
  int minSensorValues[8] = {32767, 32767, 32767, 32767, 32767, 32767, 32767, 32767}; // Temporary storage for min values per iteration

  for (int j = 0; j < 800; j++) { 
    emittersOn();                                   // Turn on emitters before charging sensors
    
                                                     
    for (int i = 0; i < sensorCount; i++) {
      high(sensorPins[i]);                            // Charge the sensor capacitors
    }
    pause(1);                                         // Short pause to allow capacitors to charge fully
    
    
    for (int i = 0; i < sensorCount; i++) {
      int time = rc_time(sensorPins[i], 1);           // Measure time for pin to go from high to low
      
      
      if (time > _maxValue) {                         // Cap the rc_time value to _maxValue if it exceeds it
        time = _maxValue;
      }

  
      if (time > maxSensorValues[i]) {                // Set the max/min we found THIS time
        maxSensorValues[i] = time;
      }
      if (time < minSensorValues[i]) {
        minSensorValues[i] = time;
      }
    }
    
    pause(1);

    for (int i = 0; i < sensorCount; i++) {         // After each iteration, update the overall min/max if necessary
      if (maxSensorValues[i] > maxValue[i]) {
        maxValue[i] = maxSensorValues[i]; 
      }
      if (minSensorValues[i] < minValue[i]) {
        minValue[i] = minSensorValues[i]; 
      }
    }
  }
  emittersOff();                                    //Turn off emitters after calibration
  low(26);
}


void readSensors() {
  emittersOn();                                     // Turn on emitters before reading sensor values
  
                                                    
  for (int i = 0; i < sensorCount; i++) {           // Charge the sensor capacitors
    high(sensorPins[i]); 
  }
  pause(1);                                         // Short pause to allow capacitors to charge fully

  
  for (int i = 0; i < sensorCount; i++) {
   sensorValues[i] = _maxValue;                     // Initialize sensor value with max value
    int time = rc_time(sensorPins[i], 1);           // Measure time for pin to go from high to low
    if(time < _maxValue) {
      sensorValues[i] = time;                       // Update with measured time if less than max value
    }
  }
  
  emittersOff();                                     // Turn off emitters after reading sensor values
}


void readSensorsAndMap() {
  readSensors();                                     // Updates sensorValues[] with the latest readings
  
  for (int i = 0; i < sensorCount; i++) {
    int calmin = minValue[i], calmax = maxValue[i];
    int denominator = calmax - calmin;
    int value = 0;

    if (denominator != 0) {                           // Prevent division by zero
      value = (sensorValues[i] - calmin) * 1000 / denominator;
    }

                                                    // Clamp the value to the 0-1000 range
    if (value < 0) value = 0;
    else if (value > 1000) value = 1000;

    sensorValues[i] = value;                        // Store the mapped value back into sensorValues[]
  }
}



int readLine() {
  readSensorsAndMap();                                // Updates sensorValues[] with the latest readings
  
  bool onLine = false;
  long weightedSum = 0;
  int valueSum = 0;
  
  for (int i = 0; i < sensorCount; i++) {
    if (sensorValues[i] > 500) {                      // 500 is a threshold for being on the line anything less is noise.
      onLine = true;
      weightedSum += (long)sensorValues[i] * (i * 1000);
      valueSum += sensorValues[i];
    }
  }

  if (!onLine) {
                                                      // If no sensor detects the line clearly and lastPosition < 1500, assume line is to the left
    if (lastPosition <(sensorCount - 1) * 1000 / 2) {
      return 0;
    } else {                                          // Otherwise, assume line is to the right
      return (sensorCount - 1) * 1000;
    }
  } else {
    lastPosition = weightedSum / valueSum;            // Calculate weighted average
    return lastPosition;
  }
}
