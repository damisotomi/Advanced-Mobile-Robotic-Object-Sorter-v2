
#ifndef PIXY2_H
#define PIXY2_H

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdint.h>


#define  BLOCK_SIZE  14                                         // block data returned in 14 bytes
#define  MAX_BLOCKS  1                                        // allow up to 10 blocks with one call
#define  BUF_SIZE     6 + (BLOCK_SIZE * MAX_BLOCKS)             // serial buffer size

#define  CCC_SIG1         0b00000001                            // color signatures
#define  CCC_SIG2         0b00000010
#define  CCC_SIG3         0b00000100
#define  CCC_SIG4         0b00001000
#define  CCC_SIG5         0b00010000
#define  CCC_SIG6         0b00100000
#define  CCC_SIG7         0b01000000
#define  CCC_ALL          0b01111111
#define  CCC_COLOR_CODES  0b10000000

#define  REQUEST_RESOLUTION     0x0C                            // get resolution (width, height) of Pixy image
#define  REQUEST_VERSION        0x0E                            // get hardware & firmware version
#define  REQUEST_BRIGHTNESS     0x10                            // set camera brightness
#define  REQUEST_SERVO          0x12                            // set pan/tilt servo positions
#define  REQUEST_LED            0x14                            // set rgb LED values
#define  REQUEST_LAMP           0x16                            // set upper and lower lamp states
#define  REQUEST_FPS            0x18                            // get frame rate
#define  REQUEST_BLOCKS         0x20                            // get signatures being tracked
#define  REQUEST_GET_RGB        0x70                            // get color information from x/y

#define  RESPONSE_RESULT        0x01                            // packet response codes
#define  RESPONSE_ERROR         0x03
#define  RESPONSE_RESOLUTION    0x0D
#define  RESPONSE_VERSION       0x0F
#define  RESPONSE_BLOCKS        0x21

#define  RESULT_OK                 0                            // result codes
#define  RESULT_ERROR             -1
#define  RESULT_BUSY              -2
#define  RESULT_CHECKSUM_ERROR    -3
#define  RESULT_TIMEOUT           -4
#define  RESULT_BUTTON_OVERRIDE   -5
#define  RESULT_PROG_CHANGING     -6


typedef struct  
{
  uint16_t signature;                                           // color signature (1..7)
  uint16_t xpos;                                                // location
  uint16_t ypos;
  uint16_t width;                                               // size
  uint16_t height;
  int16_t  angle;
  uint8_t  index;
  uint8_t  age;
} block_t;


/**
 * @brief Establish establish serial connection with Pixy
 *
 * @param rxpin Receive pin that connects to Pixy TX.
 * @param txpin Transmit pin that connects to Pixy RX.
 * @param baud Serial baud rate up to 19.2k (suggested).
 *
 * @returns 0 is successful, -1 i unable to create serial connection.
 */
int32_t pixy2_start(uint8_t rxpin, uint8_t txpin, uint16_t baud);



/**
 * @brief Request blocks (tracking data) for specified signatures.
 * 
 * @note If using color codes, an octal value returned; digits in this
 * value represent the color signatures that make up the the color code.
 *
 * @param sigmap Bitmap of desired signature(s).
 * @param maxBlocks The maximum number of blocks that to be returned.
 *
 * @returns number of blocks in response packet, a negative value on communications error.
 */
uint8_t pixy2_getBlocks(uint8_t sigmap, uint8_t maxBlocks);


/**
 * @brief Move block data from recieve buffer to block_t variable.
 *
 * @param i Index (0..blockCount-1) of desired block.
 * @param *block A pointer to block_t struct to hold the block (tracking) values.
 *
 * @returns 0 if successful, -1 if bad block index or no block data in buffer.
 */
int32_t pixy2_extractBlock(uint8_t i, uint16_t *block);


// utilities used only in pixy2.c

void      clearBuffer(void);                                    // empty rx buffer
uint8_t   recvPacket(void);                                     // wait for and capture Pixy response
int32_t   validateChecksum();                                   // valid checksum of packet in buffer
uint16_t  extract16(uint8_t i);                                 // extract 16-bit value from buffer
uint32_t  extract32(uint8_t i);                                 // extract 32-bit value from buffer
uint32_t  extractLE(uint8_t i, uint8_t n);                      // extract value from buffer


#if defined(__cplusplus)
}
#endif
/* __cplusplus */

#endif
/* PIXY2_H */


